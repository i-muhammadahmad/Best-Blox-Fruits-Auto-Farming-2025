

export const Membership_API_URL = 'http://ims.premierbpo.net/MIS/Membership/';
