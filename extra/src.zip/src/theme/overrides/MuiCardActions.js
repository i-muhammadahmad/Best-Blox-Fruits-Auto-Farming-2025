export default {
  root: {
    padding: '16px 24px'
  }
};
