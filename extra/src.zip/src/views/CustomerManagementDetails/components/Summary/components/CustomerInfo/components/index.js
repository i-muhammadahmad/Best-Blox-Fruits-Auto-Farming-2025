export { default as CustomerEdit } from './CustomerEdit';
