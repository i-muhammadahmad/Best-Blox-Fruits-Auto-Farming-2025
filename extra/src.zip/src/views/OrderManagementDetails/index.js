export { default } from './OrderManagementDetails';
