export { default } from './GeneralSettings';
