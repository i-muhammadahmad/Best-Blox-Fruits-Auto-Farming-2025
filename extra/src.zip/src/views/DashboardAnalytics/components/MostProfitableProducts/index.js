export { default } from './MostProfitableProducts';
