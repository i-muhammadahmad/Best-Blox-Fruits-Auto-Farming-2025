export { default } from './FAQ';
