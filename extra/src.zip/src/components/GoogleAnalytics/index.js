export { default } from './GoogleAnalytics';
