export { default } from './PostCard';
